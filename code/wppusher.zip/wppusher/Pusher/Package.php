<?php

namespace Pusher;

interface Package {
    public function getIdentifier();
}
